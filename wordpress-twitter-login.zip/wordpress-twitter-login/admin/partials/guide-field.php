<tr>
    <th scope="row"><label for="access-token"><?php esc_html_e('Creating my twitter application.', 'wiloke'); ?></label>
    </th>
    <td>
        <a href="http://blog.wiloke.com/how-to-get-twitter-api/" target="_blank">http://blog.wiloke.com/how-to-get-twitter-api/</a>
    </td>
</tr>