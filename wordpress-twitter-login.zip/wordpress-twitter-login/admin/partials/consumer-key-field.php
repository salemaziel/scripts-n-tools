<tr>
    <th scope="row"><label for="access-token"><?php esc_html_e('Consumer Key', 'wiloke'); ?></label></th>
    <td>
        <input id="access-token" type="text" name="twitter[consumer_key]" value="<?php echo esc_attr($aTwitter['consumer_key']); ?>" required />
    </td>
</tr>