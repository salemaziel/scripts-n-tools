=== Plugin Name ===
Contributors: logicspice
Tags: wordpress login, widget login, twitter login, twitter, social login, social networks login
Requires at least: 4.5
Tested up to:  4.6.1
Stable tag:  4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==
Twitter  Login is a WordPres plugin, which allows to adds a Twitter login button into wp-login.php and let you use Twitter avatars, period. You can also put a twitter login on the sidebar by dragging twitter login widget item on your sidebar place.


<h3>Demo URL</h3>
<a href="https://www.logicspice.com/demo/wptwitter/wp-login.php">https://www.logicspice.com/demo/wptwitter/wp-login.php</a>


<h3><strong>Question & Supports</strong></h3>
You want more features on next release? <br />

== Frequently Asked Questions ==

= Features Request & Support =


== Screenshots ==


== Changelog ==

= 1.0 =
* Released

== Upgrade Notice ==
Just upgrade via Wordpress.
